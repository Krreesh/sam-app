"""
Expose top level cli command for `init`
"""
from .command import cli
