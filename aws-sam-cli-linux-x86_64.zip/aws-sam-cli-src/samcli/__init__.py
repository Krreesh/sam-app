"""
SAM CLI version
"""

__version__ = "1.66.0"
